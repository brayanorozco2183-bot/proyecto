export const FINAL_DELIVERY_CASCADE_LOCK_CSS = `
/* === Gravity Clean Delivery Cascade Lock v1 === */
:root{
  --gfd-bg:var(--bg,#f8fafc);
  --gfd-surface:#ffffff;
  --gfd-text:var(--text,#0f172a);
  --gfd-muted:var(--muted,#475569);
  --gfd-primary:var(--primary,#0f766e);
  --gfd-primary-rgb:var(--primary-rgb,15,118,110);
  --gfd-border:rgba(148,163,184,.18);
  --gfd-border-strong:rgba(148,163,184,.28);
  --gfd-radius:clamp(1rem,1.8vw,1.45rem);
  --gfd-radius-lg:clamp(1.25rem,2.5vw,2rem);
  --gfd-shadow:0 10px 28px rgba(15,23,42,.065);
  --gfd-shadow-soft:0 5px 16px rgba(15,23,42,.045);
  --gfd-section-y:clamp(2.8rem,5vw,5rem);
}
html,body{max-width:100%;overflow-x:clip!important;}
body.gravity-clean-delivery{background:linear-gradient(180deg,#fff 0%,var(--gfd-bg) 46%,#fff 100%)!important;color:var(--gfd-text)!important;line-height:1.68;}
body.gravity-clean-delivery *,body.gravity-clean-delivery *::before,body.gravity-clean-delivery *::after{box-sizing:border-box;}
body.gravity-clean-delivery .el-container{width:100%;max-width:1180px;margin-inline:auto;padding-inline:clamp(1rem,3vw,2rem);}
body.gravity-clean-delivery img,body.gravity-clean-delivery iframe,body.gravity-clean-delivery svg,body.gravity-clean-delivery video{max-width:100%;}
body.gravity-clean-delivery a{text-decoration:none;}
body.gravity-clean-delivery h1,body.gravity-clean-delivery h2,body.gravity-clean-delivery h3{color:var(--gfd-text)!important;line-height:1.08;letter-spacing:-.035em;text-wrap:balance;margin-top:0;}
body.gravity-clean-delivery h1{font-size:clamp(2.15rem,5vw,4.55rem)!important;max-width:15ch;margin-bottom:1rem!important;}
body.gravity-clean-delivery h2{font-size:clamp(1.65rem,3vw,2.55rem)!important;max-width:18ch;margin-bottom:.8rem!important;}
body.gravity-clean-delivery h3{font-size:clamp(1.08rem,1.55vw,1.34rem)!important;margin-bottom:.5rem!important;}
body.gravity-clean-delivery p{margin:0;color:var(--gfd-muted);}
body.gravity-clean-delivery ul:empty,body.gravity-clean-delivery ol:empty,body.gravity-clean-delivery p:empty,body.gravity-clean-delivery h2:empty,body.gravity-clean-delivery h3:empty,body.gravity-clean-delivery .service-card:empty,body.gravity-clean-delivery .step-card:empty{display:none!important;}

/* Header and navigation: never show desktop and mobile menus at the same time. */
body.gravity-clean-delivery .site-header{position:sticky;top:0;z-index:100;padding:.65rem 0;background:rgba(255,255,255,.95)!important;border-bottom:1px solid rgba(148,163,184,.12);box-shadow:0 8px 24px rgba(15,23,42,.045);}
body.gravity-clean-delivery .site-header__inner{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:1rem!important;min-height:3.7rem;padding:.55rem .75rem;border-radius:999px;background:#fff;border:1px solid rgba(148,163,184,.14);box-shadow:var(--gfd-shadow-soft);}
body.gravity-clean-delivery .brand,body.gravity-clean-delivery .brand__name,body.gravity-clean-delivery .site-header__brand-name{display:inline-flex;align-items:center;color:var(--gfd-text)!important;font-weight:950;letter-spacing:-.025em;white-space:nowrap;}
body.gravity-clean-delivery .nav--desktop{display:flex!important;align-items:center;gap:.7rem;margin-left:auto;}
body.gravity-clean-delivery .nav__links-group{display:flex!important;align-items:center;gap:.25rem;flex-wrap:wrap;}
body.gravity-clean-delivery .nav__link{display:inline-flex!important;align-items:center;min-height:2.45rem;padding:.56rem .78rem;border-radius:999px;color:var(--gfd-text)!important;font-weight:850;font-size:.92rem;}
body.gravity-clean-delivery .nav__link:hover,body.gravity-clean-delivery .nav__link.is-active{background:rgba(15,23,42,.055);}
body.gravity-clean-delivery .nav-mobile{display:none!important;position:relative;margin-left:auto;}
body.gravity-clean-delivery .nav-mobile__summary{cursor:pointer;list-style:none;display:inline-flex;align-items:center;justify-content:center;min-height:2.55rem;padding:0 .9rem;border-radius:999px;background:#fff;border:1px solid var(--gfd-border);font-weight:900;color:var(--gfd-text);}
body.gravity-clean-delivery .nav-mobile__summary::-webkit-details-marker{display:none;}
body.gravity-clean-delivery .nav-mobile__panel{position:absolute;right:0;margin-top:.75rem;width:min(22rem,calc(100vw - 2rem));padding:.9rem;border-radius:1.15rem;background:#fff;border:1px solid var(--gfd-border);box-shadow:var(--gfd-shadow);z-index:120;}
body.gravity-clean-delivery .nav-mobile__links{display:grid!important;gap:.35rem;}
body.gravity-clean-delivery .nav-mobile__link{display:flex;align-items:center;min-height:2.45rem;padding:.58rem .75rem;border-radius:.85rem;color:var(--gfd-text)!important;font-weight:850;}
@media (max-width:760px){
  body.gravity-clean-delivery .site-header{top:0;padding:.55rem 0;}
  body.gravity-clean-delivery .site-header__inner{border-radius:1.1rem;}
  body.gravity-clean-delivery .nav--desktop{display:none!important;}
  body.gravity-clean-delivery .nav-mobile{display:block!important;}
}
@media (min-width:761px){
  body.gravity-clean-delivery .nav-mobile{display:none!important;}
  body.gravity-clean-delivery .nav--desktop{display:flex!important;}
}

/* Sections and safe grids. */
body.gravity-clean-delivery .el-section-wrapper{padding-block:0!important;background:transparent!important;}
body.gravity-clean-delivery .block-section,body.gravity-clean-delivery .semantic-section,body.gravity-clean-delivery .el-section{padding:var(--gfd-section-y) 0!important;}
body.gravity-clean-delivery .block-section__inner,body.gravity-clean-delivery .section-shell,body.gravity-clean-delivery .semantic-section__container{min-width:0;}
body.gravity-clean-delivery .block__header,body.gravity-clean-delivery .section-title,body.gravity-clean-delivery .testimonials-section__header{display:flex;flex-direction:column;align-items:flex-start;text-align:left;gap:.35rem;margin-bottom:clamp(1.15rem,2.5vw,2rem)!important;max-width:820px;}
body.gravity-clean-delivery .block__header p,body.gravity-clean-delivery .block__subtitle,body.gravity-clean-delivery .editorial-lead{max-width:68ch;color:var(--gfd-muted)!important;font-size:clamp(1rem,1.3vw,1.12rem);}
body.gravity-clean-delivery .block__eyebrow,body.gravity-clean-delivery .hero__eyebrow,body.gravity-clean-delivery .card__eyebrow{display:inline-flex;width:max-content;max-width:100%;align-items:center;min-height:2rem;padding:.38rem .68rem;border-radius:999px;background:rgba(var(--gfd-primary-rgb),.075);border:1px solid rgba(var(--gfd-primary-rgb),.13);color:var(--gfd-primary)!important;font-size:.76rem;font-weight:950;letter-spacing:.08em;text-transform:uppercase;margin-bottom:.85rem;}

/* Hero with local image fallback. */
body.gravity-clean-delivery .hero{padding-top:clamp(1.35rem,3vw,2.25rem)!important;}
body.gravity-clean-delivery .hero__minimal,body.gravity-clean-delivery .hero__shell,body.gravity-clean-delivery .hero__centered--with-media{display:grid!important;grid-template-columns:minmax(0,.95fr) minmax(300px,.72fr)!important;align-items:center!important;gap:clamp(1.3rem,3.5vw,3rem)!important;max-width:1180px!important;margin-inline:auto!important;padding:clamp(1.35rem,3vw,2.6rem)!important;border-radius:var(--gfd-radius-lg)!important;background:radial-gradient(circle at 100% 0,rgba(var(--gfd-primary-rgb),.09),transparent 34%),#fff!important;border:1px solid rgba(148,163,184,.16)!important;box-shadow:var(--gfd-shadow)!important;color:var(--gfd-text)!important;overflow:hidden;}
body.gravity-clean-delivery .hero__minimal>.hero__eyebrow,body.gravity-clean-delivery .hero__minimal>h1,body.gravity-clean-delivery .hero__minimal>.hero__subtitle,body.gravity-clean-delivery .hero__minimal>.cta-row,body.gravity-clean-delivery .hero__minimal>.hero__bullets{grid-column:1;}
body.gravity-clean-delivery .hero__minimal>.hero-visual{grid-column:2;grid-row:1 / span 6;margin:0!important;}
body.gravity-clean-delivery .hero-visual{margin:0!important;min-width:0;}
body.gravity-clean-delivery .hero-visual__frame,body.gravity-clean-delivery .hero-visual__fallback{position:relative;min-height:clamp(280px,34vw,440px);border-radius:var(--gfd-radius-lg);overflow:hidden;background:radial-gradient(circle at 70% 18%,rgba(255,255,255,.28),transparent 26%),linear-gradient(135deg,var(--gfd-primary),color-mix(in srgb,var(--gfd-primary),#fff 26%));box-shadow:var(--gfd-shadow);border:1px solid rgba(255,255,255,.75);}
body.gravity-clean-delivery .hero-visual__frame img{display:block;width:100%;height:100%;min-height:inherit;object-fit:cover;}
body.gravity-clean-delivery .hero-visual__frame.image-failed::before,body.gravity-clean-delivery .hero-visual__frame:not(:has(img))::before{content:'Servicio local';position:absolute;inset:auto 1.2rem 1.2rem 1.2rem;color:#fff;font-weight:950;font-size:clamp(1.15rem,2.4vw,2rem);letter-spacing:-.04em;}
body.gravity-clean-delivery .hero-visual__frame.image-failed::after{content:'';position:absolute;inset:0;background:radial-gradient(circle at 70% 18%,rgba(255,255,255,.24),transparent 26%),linear-gradient(135deg,var(--gfd-primary),#0f172a);z-index:-1;}

/* Cards, lists and block internals. */
body.gravity-clean-delivery .services-grid__cards,body.gravity-clean-delivery .semantic-items,body.gravity-clean-delivery .trust-grid,body.gravity-clean-delivery .local-proof__grid,body.gravity-clean-delivery .local-proof__signal-list,body.gravity-clean-delivery .process-steps__timeline,body.gravity-clean-delivery .price-guidance__cards,body.gravity-clean-delivery .testimonials-grid,body.gravity-clean-delivery .internal-links-grid{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(min(100%,17rem),1fr))!important;gap:clamp(.9rem,1.8vw,1.25rem)!important;align-items:stretch;}
body.gravity-clean-delivery .services-grid__magazine,body.gravity-clean-delivery .local-proof__coverage,body.gravity-clean-delivery .process-steps__rail-layout,body.gravity-clean-delivery .price-guidance__insight,body.gravity-clean-delivery .cta-panel__consult,body.gravity-clean-delivery .map-block__context{display:grid!important;grid-template-columns:minmax(0,.92fr) minmax(0,1.08fr)!important;gap:clamp(1.1rem,2.8vw,2.25rem)!important;align-items:start;}
body.gravity-clean-delivery .services-grid__magazine-lead,body.gravity-clean-delivery .services-grid__magazine-stack,body.gravity-clean-delivery .local-proof__coverage-copy,body.gravity-clean-delivery .local-proof__coverage-cards,body.gravity-clean-delivery .process-steps__rail-copy,body.gravity-clean-delivery .price-guidance__insight-copy,body.gravity-clean-delivery .price-guidance__insight-panels,body.gravity-clean-delivery .cta-panel__consult-copy,body.gravity-clean-delivery .map-block__context-copy{display:grid;gap:1rem;min-width:0;}
body.gravity-clean-delivery .service-card,body.gravity-clean-delivery .proof-card,body.gravity-clean-delivery .step-card,body.gravity-clean-delivery .price-card,body.gravity-clean-delivery .faq-item,body.gravity-clean-delivery .faq-entry,body.gravity-clean-delivery .faq-item-refined,body.gravity-clean-delivery .testimonial-card,body.gravity-clean-delivery .semantic-card,body.gravity-clean-delivery .trust-band__signal-card,body.gravity-clean-delivery .conversion-proof-item,body.gravity-clean-delivery .internal-links-item,body.gravity-clean-delivery .services-grid__magazine-feature,body.gravity-clean-delivery .map-block__support{min-width:0;border-radius:var(--gfd-radius)!important;background:#fff!important;border:1px solid var(--gfd-border)!important;box-shadow:var(--gfd-shadow-soft)!important;padding:clamp(1.05rem,2vw,1.45rem)!important;}
body.gravity-clean-delivery .service-card p,body.gravity-clean-delivery .proof-card p,body.gravity-clean-delivery .step-card p,body.gravity-clean-delivery .price-card p,body.gravity-clean-delivery .semantic-card p{color:var(--gfd-muted)!important;}
body.gravity-clean-delivery .gravity-list-card{display:grid;gap:.55rem;list-style:none;margin:1rem 0 0;padding:0;}
body.gravity-clean-delivery .gravity-list-card>li{position:relative;padding:.72rem .85rem .72rem 2.25rem;border-radius:.95rem;background:#fff;border:1px solid var(--gfd-border);box-shadow:var(--gfd-shadow-soft);color:var(--gfd-muted);}
body.gravity-clean-delivery .gravity-list-card>li::before{content:'✓';position:absolute;left:.8rem;top:.72rem;display:inline-grid;place-items:center;width:1.1rem;height:1.1rem;border-radius:999px;background:rgba(var(--gfd-primary-rgb),.09);color:var(--gfd-primary);font-weight:950;font-size:.74rem;}
body.gravity-clean-delivery .service-card__meta,body.gravity-clean-delivery .step-card__meta,body.gravity-clean-delivery .step-row__meta,body.gravity-clean-delivery .proof-row__meta,body.gravity-clean-delivery .price-card__facts,body.gravity-clean-delivery .services-grid__trust,body.gravity-clean-delivery .urgency-banner__pills,body.gravity-clean-delivery .block__pills{display:flex;flex-wrap:wrap;gap:.45rem;list-style:none;margin:.85rem 0 0!important;padding:0!important;}
body.gravity-clean-delivery .service-card__meta li,body.gravity-clean-delivery .step-card__meta li,body.gravity-clean-delivery .step-row__meta li,body.gravity-clean-delivery .proof-row__meta li,body.gravity-clean-delivery .price-card__facts li,body.gravity-clean-delivery .block__pill{display:inline-flex;align-items:center;min-height:1.95rem;padding:.38rem .6rem;border-radius:999px;background:rgba(var(--gfd-primary-rgb),.06);border:1px solid rgba(var(--gfd-primary-rgb),.11);color:var(--gfd-primary);font-size:.81rem;font-weight:850;line-height:1.15;}
body.gravity-clean-delivery .process-step-rail,body.gravity-clean-delivery .local-proof__signal,body.gravity-clean-delivery .trust-band__signal-card,body.gravity-clean-delivery .proof-row--stacked{display:grid!important;grid-template-columns:auto minmax(0,1fr)!important;gap:.85rem;align-items:start;}
body.gravity-clean-delivery .process-step-rail__index,body.gravity-clean-delivery .step-card__index,body.gravity-clean-delivery .local-proof__signal-index,body.gravity-clean-delivery .trust-band__signal-index,body.gravity-clean-delivery .proof-row__ordinal,body.gravity-clean-delivery .service-card__icon{display:inline-grid;place-items:center;width:2.65rem;height:2.65rem;border-radius:999px;background:linear-gradient(135deg,var(--gfd-primary),color-mix(in srgb,var(--gfd-primary),#000 20%))!important;color:#fff!important;font-weight:950;box-shadow:0 9px 20px rgba(var(--gfd-primary-rgb),.17);}

/* CTA, FAQ, map and footer. */
body.gravity-clean-delivery .cta-primary,body.gravity-clean-delivery .nav__cta,body.gravity-clean-delivery .nav-mobile__cta,body.gravity-clean-delivery .card__btn,body.gravity-clean-delivery .internal-links-item__anchor{display:inline-flex;align-items:center;justify-content:center;gap:.45rem;min-height:3rem;padding:.75rem 1.05rem;border-radius:999px;background:linear-gradient(135deg,var(--gfd-primary),color-mix(in srgb,var(--gfd-primary),#000 18%))!important;color:#fff!important;border:1px solid rgba(255,255,255,.16)!important;font-weight:950;box-shadow:0 10px 22px rgba(var(--gfd-primary-rgb),.17)!important;}
body.gravity-clean-delivery .block__cta-group{display:flex;align-items:center;gap:.7rem;flex-wrap:wrap;margin-top:1.05rem!important;}
body.gravity-clean-delivery .block__cta-note,body.gravity-clean-delivery .block__cta-phone{display:inline-flex;align-items:center;min-height:2.65rem;max-width:34rem;padding:.65rem .85rem;border-radius:999px;background:rgba(15,23,42,.035);border:1px solid var(--gfd-border);color:var(--gfd-muted);font-size:.88rem;font-weight:650;line-height:1.25;}
body.gravity-clean-delivery .urgency-banner,body.gravity-clean-delivery .cta-panel__banner,body.gravity-clean-delivery .section-cta--terminal{border-radius:var(--gfd-radius-lg)!important;background:radial-gradient(circle at 100% 0,rgba(var(--gfd-primary-rgb),.09),transparent 32%),#fff!important;border:1px solid rgba(var(--gfd-primary-rgb),.15)!important;box-shadow:var(--gfd-shadow)!important;padding:clamp(1.15rem,2.4vw,1.75rem)!important;}
body.gravity-clean-delivery .urgency-banner{display:grid!important;grid-template-columns:minmax(0,1fr) minmax(140px,.26fr) minmax(200px,.38fr)!important;gap:1rem;align-items:center;position:relative;overflow:hidden;}
body.gravity-clean-delivery .urgency-banner__rail{position:absolute;inset:0 auto 0 0;width:.34rem;background:var(--gfd-primary);}
body.gravity-clean-delivery .faq-block__accordion,body.gravity-clean-delivery .faq-block__accordion--refined{display:grid;gap:.78rem;max-width:940px;}
body.gravity-clean-delivery .faq-summary-refined{display:grid!important;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:.75rem;cursor:pointer;list-style:none;color:var(--gfd-text);font-weight:900;padding:1rem 1.05rem!important;}
body.gravity-clean-delivery .faq-summary-refined::-webkit-details-marker{display:none;}
body.gravity-clean-delivery .faq-summary-refined:after{content:'+';font-weight:950;color:var(--gfd-primary);}
body.gravity-clean-delivery details[open]>.faq-summary-refined:after{content:'–';}
body.gravity-clean-delivery .faq-content-refined{padding:0 1.05rem 1.05rem 4rem!important;color:var(--gfd-muted);}
body.gravity-clean-delivery .map-block__frame,body.gravity-clean-delivery .map-wrapper,body.gravity-clean-delivery .map-boxed-wrapper,body.gravity-clean-delivery .map-directory__visual{position:relative;min-height:clamp(300px,40vw,440px)!important;border-radius:var(--gfd-radius)!important;background:linear-gradient(135deg,#dbe4ee,#f8fafc)!important;border:1px solid var(--gfd-border)!important;box-shadow:var(--gfd-shadow)!important;overflow:hidden;}
body.gravity-clean-delivery .map-block__iframe,body.gravity-clean-delivery .map-iframe,body.gravity-clean-delivery iframe.map-iframe{display:block;width:100%;height:100%;min-height:inherit;border:0;}
body.gravity-clean-delivery .footer-editorial,body.gravity-clean-delivery .site-footer{padding:clamp(2.4rem,5vw,4.4rem) 0!important;background:linear-gradient(135deg,#0f172a,color-mix(in srgb,#0f172a 82%,var(--gfd-primary) 18%))!important;color:#fff!important;}
body.gravity-clean-delivery .footer-editorial p,body.gravity-clean-delivery .footer-editorial a,body.gravity-clean-delivery .site-footer p,body.gravity-clean-delivery .site-footer a{color:rgba(255,255,255,.78)!important;}
body.gravity-clean-delivery .footer-editorial h2,body.gravity-clean-delivery .footer-editorial h3,body.gravity-clean-delivery .footer-editorial strong,body.gravity-clean-delivery .site-footer h2,body.gravity-clean-delivery .site-footer h3{color:#fff!important;}
@media (max-width:900px){
  body.gravity-clean-delivery .hero__minimal,body.gravity-clean-delivery .hero__shell,body.gravity-clean-delivery .hero__centered--with-media,body.gravity-clean-delivery .services-grid__magazine,body.gravity-clean-delivery .local-proof__coverage,body.gravity-clean-delivery .process-steps__rail-layout,body.gravity-clean-delivery .price-guidance__insight,body.gravity-clean-delivery .cta-panel__consult,body.gravity-clean-delivery .map-block__context,body.gravity-clean-delivery .urgency-banner{grid-template-columns:minmax(0,1fr)!important;}
  body.gravity-clean-delivery .hero__minimal>.hero-visual{grid-column:auto!important;grid-row:auto!important;}
  body.gravity-clean-delivery h1{max-width:100%!important;}
}
@media (max-width:640px){
  body.gravity-clean-delivery .el-container{padding-inline:1rem!important;}
  body.gravity-clean-delivery .hero__minimal,body.gravity-clean-delivery .hero__shell{padding:1.05rem!important;border-radius:1.15rem!important;}
  body.gravity-clean-delivery .hero-visual__frame{min-height:250px!important;}
  body.gravity-clean-delivery .cta-primary,body.gravity-clean-delivery .card__btn,body.gravity-clean-delivery .internal-links-item__anchor{width:100%!important;}
  body.gravity-clean-delivery .process-step-rail,body.gravity-clean-delivery .local-proof__signal,body.gravity-clean-delivery .trust-band__signal-card,body.gravity-clean-delivery .proof-row--stacked{grid-template-columns:minmax(0,1fr)!important;}
  body.gravity-clean-delivery .faq-content-refined{padding-left:1.05rem!important;}
}
`;
